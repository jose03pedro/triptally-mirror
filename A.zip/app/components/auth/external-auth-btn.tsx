"use client";

import { useState } from "react";

export function ExternalAuthBtn({ provider }: { provider: string }) {
  const [errors, setErrors] = useState<string[]>([]);

  const handleGoogleLogin = () => {
    if (typeof window === "undefined" || !window.google) return;

    window.google.accounts.id.initialize({
      client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID!,
      callback: async (response: any) => {
        const res = await fetch("/api/auth/google", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ idToken: response.credential }),
        });

        const data = await res.json();

        if (data.success && data.token) {
          localStorage.setItem("token", data.token);
          window.location.href = "/profile"; // redirect
        } else {
          // save errors in state
          setErrors(data.errors?.email || [data.message || "Login failed"]);
        }
      },
    });

    window.google.accounts.id.prompt();
  };

  return (
    <div>
      <button
        onClick={handleGoogleLogin}
        className="btn btn-outline-secondary w-100 position-relative"
      >
        <img
          src={`/icons/${provider.toLowerCase()}.png`}
          alt={`${provider} logo`}
          width={18}
          className="position-absolute start-0 top-50 translate-middle-y mx-2"
        />
        <span className="d-block text-center w-100">
          Continue with {provider}
        </span>
      </button>

      {/* Render errors */}
      {errors.length > 0 && (
        <div className="mt-2 text-danger fs-7">
          {errors.map((err, i) => (
            <div key={i}>{err}</div>
          ))}
        </div>
      )}
    </div>
  );
}
