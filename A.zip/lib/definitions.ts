import * as z from "zod";
import {User} from "@/types/user/types";

// -------------------- Signup Schema --------------------
export const SignupFormSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email." }).trim(),
  password: z
    .string()
    .min(8, { message: "Must be at least 8 characters long" })
    .regex(/[a-zA-Z]/, { message: "Must contain at least one letter." })
    .regex(/[0-9]/, { message: "Must contain at least one number." })
    .regex(/[^a-zA-Z0-9]/, {
      message: "Must contain at least one special character.",
    })
    .trim(),
  first_name: z.string().trim().nonempty("First name is required"),
  last_name: z.string().trim().nonempty("Last name is required"),
});

// -------------------- Create Trip Schema --------------------
export const CreateTripSchema = z
  .object({
    title: z.string().trim().nonempty("Title is required"),
    currency: z.string().trim().nonempty("Currency is required"),
    startDate: z.string().trim().nonempty("Start date is required"),
    endDate: z.string().trim().nonempty("End date is required"),
    cities: z
      .array(
        z.object({
          name: z.string().trim().nonempty("Please select a valid city"),
          country: z.string().trim(),
        })
      )
      .min(1, "At least one city is required"),
  })
  .refine(
    (data) => {
      if (!data.startDate || !data.endDate) return true;
      const start = new Date(data.startDate);
      const end = new Date(data.endDate);
      return end >= start;
    },
    {
      message: "Must be after the start date",
      path: ["endDate"],
    }
  );

// -------------------- Create Expense Schema --------------------
export const CreateExpenseSchema = z.object({
  tripId: z.string().min(1, "Trip is required"),
  description: z.string().min(1, "Description is required"),
  category: z.string().min(1, "Category is required"),
  currency: z.string().min(1, "Currency is required"),

  date: z
    .string()
    .min(1, "Date is required")
    .refine((val) => !isNaN(Date.parse(val)), {
      message: "Date must be a valid date",
    }),

  value: z
    .string()
    .min(1, "Value is required")
    .refine((v) => !isNaN(Number(v)), {
      message: "Value must be a valid number",
    }),
});

export const EditExpenseSchema = z.object({
  expenseId: z.string().min(1, "Expense ID is required"),
  description: z.string().min(1, "Description is required"),
  category: z.string().min(1, "Category is required"),
  currency: z.string().min(1, "Currency is required"),

  date: z
    .string()
    .min(1, "Date is required")
    .refine((val) => !isNaN(Date.parse(val)), {
      message: "Date must be a valid date",
    }),

  value: z
    .string()
    .min(1, "Value is required")
    .refine((v) => !isNaN(Number(v)), {
      message: "Value must be a valid number",
    }),
});

// -------------------- Edit User Schema --------------------
export const EditUserSchema = z.object({
  first_name: z.string().trim().nonempty("First name is required"),
  last_name: z.string().trim().nonempty("Last name is required"),
  current_password: z.string().trim().nonempty("Current password is required"),
  avatar: z.union([z.string().url(), z.instanceof(File)]).optional(),
});

// -------------------- Change Password Schema --------------------
export const ChangePasswordSchema = z.object({
  password: z
    .string()
    .min(8, { message: "Must be at least 8 characters long" })
    .regex(/[a-zA-Z]/, { message: "Must contain at least one letter." })
    .regex(/[0-9]/, { message: "Must contain at least one number." })
    .regex(/[^a-zA-Z0-9]/, {
      message: "Must contain at least one special character.",
    })
    .trim(),
});

// -------------------- Traveler Profile --------------------
export const TravelerProfileSchema = z.object({
  travelFrequency: z.string().optional(),
  preferredTransport: z.array(z.string()).optional(),
  accommodationType: z.string().optional(),
  budgetRange: z.string().optional(),
  dietaryRestrictions: z.array(z.string()).optional(),
  mobilityNeeds: z.string().optional(),
  interests: z.array(z.string()).optional(),
  languagesSpoken: z.array(z.string()).optional(),
  tripStyle: z.string().optional(),
  notes: z.string().optional(),
});

// -------------------- Types --------------------
export type AuthErrors = {
  email?: string[];
  password?: string[];
  first_name?: string[];
  last_name?: string[];
};

export type AuthResponse = {
  user?: User | null;
  success: boolean;
  token?: string;
  errors?: AuthErrors;
};
