"use client";

import { jwtDecode } from "jwt-decode";
import { useState, useEffect } from "react";
import User from "@/app/models/User";

type DecodedToken = {
  user: {
    id: string;
    email: string;
    first_name: string;
    last_name: string;
  };
  exp: number;
  iat: number;
};

export function useAuth() {
  // `undefined` = not checked yet, `null` = checked and unauthenticated, object = authenticated
  const [user, setUser] = useState<DecodedToken | null | undefined>(undefined);
  useEffect(() => {
    // Run the token check inside an async loader and await a microtask
    // so we don't call setState synchronously during render/effect setup.
    const load = async () => {
      await Promise.resolve(); // ensure async so setState won't be synchronous here

      const token = localStorage.getItem("token");
      if (!token) {
        setUser(null);
        return;
      }

      try {
        const decoded = jwtDecode<DecodedToken>(token);

        // Check if token is expired
        if (decoded.exp * 1000 < Date.now()) {
          console.warn("Token expired");
          localStorage.removeItem("token");
          setUser(null);
        } else {
          setUser(decoded);
        }
      } catch (err) {
        console.error("Invalid token:", err);
        localStorage.removeItem("token");
        setUser(null);
      }
    };

    load();
  }, []);

  return user;
}
